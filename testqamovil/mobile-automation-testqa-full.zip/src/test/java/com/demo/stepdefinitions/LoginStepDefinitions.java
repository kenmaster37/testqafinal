package com.demo.stepdefinitions;

import io.cucumber.java.es.*;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import org.openqa.selenium.WebDriver;
import com.demo.tasks.Login;
import com.demo.questions.HomeVisible;

import static net.serenitybdd.screenplay.GivenWhenThen.*;

public class LoginStepDefinitions {

    @io.cucumber.java.Before
    public void setTheStage() {
        OnStage.setTheStage(new OnlineCast());
    }

    @Dado("que {string} abre la app")
    public void que_abre_la_app(String actorName) {
        Actor actor = OnStage.theActorCalled(actorName);
        // WebDriver ya es gestionado por Serenity
    }

    @Cuando("ingresa usuario {string} y clave {string}")
    public void ingresa_credenciales(String user, String pass) {
        OnStage.theActorInTheSpotlight().attemptsTo(Login.withCredentials(user, pass));
    }

    @Entonces("debe ver el home de la aplicación")
    public void valida_home() {
        OnStage.theActorInTheSpotlight().should(seeThat(HomeVisible.isDisplayed()));
    }
}
