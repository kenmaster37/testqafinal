package com.demo.ui;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class HomePage {
    public static final Target HOME_LABEL = Target.the("products title")
            .located(By.xpath("//*[@text='PRODUCTS']"));
}
