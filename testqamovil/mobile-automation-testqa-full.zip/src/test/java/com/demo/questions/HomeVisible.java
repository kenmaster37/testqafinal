package com.demo.questions;

import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.Actor;
import com.demo.ui.HomePage;

public class HomeVisible implements Question<Boolean> {

    public static HomeVisible isDisplayed() {
        return new HomeVisible();
    }

    @Override
    public Boolean answeredBy(Actor actor) {
        return HomePage.HOME_LABEL.resolveFor(actor).isVisible();
    }
}
